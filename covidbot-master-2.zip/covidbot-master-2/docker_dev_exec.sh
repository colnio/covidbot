#!/bin/bash

docker exec -it bot bash