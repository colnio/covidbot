#!/bin/bash

docker stop bot